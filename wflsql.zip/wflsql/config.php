<?php

return [
	'host' => 'sql32.lh.pl', 
	'user' => 'serwer22982_wfl',
	'password' => '123456789',
	'database' => 'serwer22982_wfl'
];
